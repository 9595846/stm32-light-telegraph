#ifndef STM32F10X_CONF_H
#define STM32F10X_CONF_H
#include "stm32f10x_flash.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#include "misc.h"
#define assert_param(expr) ((void)0)
#endif
